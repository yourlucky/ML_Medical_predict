## Directories
* goal1 includes source codes such as classifiers (KNN, Bayesian Network, SVM, Neural Network), regressors (Linear Regression, KNN, Neural Network), and test codes that are used to predict our project goal 1.
* goals23 includes source codes to predict our project goals 2 and 3.

